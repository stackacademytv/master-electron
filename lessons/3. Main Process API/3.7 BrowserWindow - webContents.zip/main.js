// Modules to control application life and create native browser window
const {app, BrowserWindow, webContents} = require('electron')
const path = require('path')

function createWindow () {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    x: 100,
    y: 100,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  })

  // and load the index.html of the app.
  mainWindow.loadFile('index.html')
  // mainWindow.loadURL('https://httpbin.org/basic-auth/user/passwd')

  let wc = mainWindow.webContents

  wc.on( 'context-menu', (e, params) => {

    // console.log( `Context menu opened on: ${params.mediaType} at x: ${params.x}, y: ${params.y}` );
    // console.log( `User selected text: ${params.selectionText}` );
    // console.log( `Selection can be copied: ${params.editFlags.canCopy}` );

    wc.executeJavaScript( `alert('${params.selectionText}')` ).then( result => 1)
  })

  // wc.on( 'media-started-playing', () => {
  //   console.log('Video started');
  // })
  //
  // wc.on( 'media-paused', () => {
  //   console.log('Video paused');
  // })

  // wc.on( 'did-navigate', (e, url, statusCode, message) => {
  //
  //   console.log('Navigated to: ' + url);
  //   console.log(statusCode);
  // })
  //
  // wc.on( 'login', (e, authenticationResponseDetails, authInfo, callback) => {
  //   console.log('Authenticating');
  //   callback('user', 'passwd')
  // })

  // console.log( webContents.getAllWebContents() );

  // wc.on( 'before-input-event', (e, input) => {
  //
  //   console.log( input.key, input.type );
  // })

  // wc.on( 'will-navigate', (e, url) => {
  //   console.log('Prevented navigation to: ' + url );
  //   e.preventDefault()
  // })

  // wc.on( 'did-finish-load', () => {
  //   console.log('Content fully loaded');
  // })
  //
  // wc.on( 'dom-ready', () => {
  //   console.log('DOM Ready');
  // })

  // Open the DevTools.
  // mainWindow.webContents.openDevTools()
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
