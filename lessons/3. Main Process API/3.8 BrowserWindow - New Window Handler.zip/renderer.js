
document.getElementById('info').onclick = e => {

  // Prevent link follow
  e.preventDefault()

  window.open('info.html', null, 'frame=false, width=340, height=80')
}
